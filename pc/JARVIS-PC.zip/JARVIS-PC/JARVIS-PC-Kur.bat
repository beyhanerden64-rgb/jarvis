@echo off
chcp 65001 >nul
title JARVIS bilgisayar yardimcisi - kurulum
echo.
echo  JARVIS bilgisayar yardimcisi kuruluyor...
echo.
set "DEST=%LOCALAPPDATA%\JARVIS-PC"
where py >nul 2>nul && set "PY=py" && goto :havepy
where python >nul 2>nul && python -c "import sys" >nul 2>nul && set "PY=python" && goto :havepy
echo  Python bulunamadi. Ucretsiz Python kuruluyor (winget)...
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
  echo  Otomatik kurulamadi. Microsoft Store'da Python 3.12 sayfasi aciliyor; "Al/Yukle"ye bas, sonra bu dosyayi tekrar calistir.
  start ms-windows-store://pdp/?productid=9NCVDN91XZQP
  pause
  exit /b
)
set "PY=py"
:havepy
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0jarvis_pc.py" "%DEST%\jarvis_pc.py" >nul
for /f "delims=" %%P in ('%PY% -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"') do set "PYW=%%P"
> "%DEST%\JARVIS-PC.vbs" echo CreateObject("WScript.Shell").Run """%PYW%"" ""%DEST%\jarvis_pc.py""", 0, False
copy /Y "%DEST%\JARVIS-PC.vbs" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\JARVIS-PC.vbs" >nul
taskkill /F /IM pythonw.exe /FI "WINDOWTITLE eq JARVIS*" >nul 2>nul
wscript "%DEST%\JARVIS-PC.vbs"
for /f "delims=" %%K in ('%PY% "%DEST%\jarvis_pc.py" --kod') do set "KOD=%%K"
echo.
echo  ======================================================
echo    KURULUM TAMAM. Yardimci arka planda calisiyor ve
echo    bilgisayar her acildiginda kendiliginden baslar.
echo.
echo    ERISIM KODU:  %KOD%
echo.
echo    JARVIS - BAGLANTI - "Yardimci erisim kodu" kutusuna yaz.
echo  ======================================================
echo.
pause
