# -*- coding: utf-8 -*-
"""JARVIS bilgisayar yardımcısı (Windows) — yalnızca Python standart kütüphanesi.

Yalnız bu bilgisayardan (127.0.0.1) erişilebilir. JARVIS web uygulaması komut gönderir; yardımcı yalnız izin
listesindeki işlemleri yapar. Tehlikeli işlemler (kapatma, PowerShell, silme, tarama, yedek, klavye) uygulamada
onaylanmadan çalışmaz. Telefon köprüsü açıksa, komutlar şifre anahtarıyla imzalanmış olarak GitHub Gist üzerinden gelir.
"""
import base64, ctypes, datetime, hashlib, hmac, json, os, platform, secrets, shutil, subprocess, sys, tempfile, threading, time, urllib.request, webbrowser, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = '3.0.0'
PORT = 8765
ORIGINS = {'https://beyhanerden64-rgb.github.io', 'http://localhost:8080', 'http://127.0.0.1:8080'}
HOME = os.path.expanduser('~')
BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(BASE, 'jarvis_pc.json')
WORK = os.path.join(HOME, 'Documents', 'JARVIS')
WIN = os.name == 'nt'
NO_WINDOW = 0x08000000 if WIN else 0

APPS = {  # izin listesi: sesli ad → komut
    'not defteri': 'notepad', 'notepad': 'notepad', 'hesap makinesi': 'calc', 'chrome': 'chrome', 'edge': 'msedge',
    'word': 'winword', 'excel': 'excel', 'powerpoint': 'powerpnt', 'paint': 'mspaint', 'dosyalar': 'explorer',
    'dosya gezgini': 'explorer', 'vscode': 'code', 'kod': 'code', 'ayarlar': 'ms-settings:', 'spotify': 'spotify:',
    'whatsapp': 'whatsapp:', 'telegram': 'tg:', 'görev yöneticisi': 'taskmgr', 'gorev yoneticisi': 'taskmgr',
    'kamera': 'microsoft.windows.camera:', 'takvim': 'outlookcal:', 'posta': 'outlookmail:', 'ekran alıntısı': 'ms-screenclip:',
    'firefox': 'firefox', 'teams': 'msteams:', 'zoom': 'zoommtg:', 'obs': 'obs64'
}
PROC = {'notepad': 'notepad.exe', 'chrome': 'chrome.exe', 'msedge': 'msedge.exe', 'winword': 'WINWORD.EXE', 'excel': 'EXCEL.EXE',
        'powerpnt': 'POWERPNT.EXE', 'mspaint': 'mspaint.exe', 'code': 'Code.exe', 'spotify:': 'Spotify.exe', 'whatsapp:': 'WhatsApp.exe',
        'calc': 'CalculatorApp.exe', 'firefox': 'firefox.exe', 'tg:': 'Telegram.exe', 'obs64': 'obs64.exe', 'taskmgr': 'Taskmgr.exe'}
RISKY = {'kapat', 'powershell', 'temizlik_sil', 'tarama', 'yaz', 'yedekle', 'dosya_olustur'}
TEXT_EXT = ('.txt', '.md', '.csv', '.json', '.log', '.py', '.js', '.html', '.css', '.ini', '.xml', '.yaml', '.yml')


def load_cfg():
    try:
        with open(CONFIG, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_cfg(c):
    with open(CONFIG, 'w', encoding='utf-8') as f:
        json.dump(c, f, ensure_ascii=False, indent=1)


cfg = load_cfg()
if not cfg.get('kod'):
    a = secrets.token_hex(2).upper(); b = secrets.token_hex(2).upper()
    cfg['kod'] = f'{a}-{b}'
    save_cfg(cfg)
APPS.update({k.lower(): v for k, v in cfg.get('uygulamalar', {}).items()})


def fold(s):
    return str(s or '').lower().replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o').replace('ç', 'c').replace('İ', 'i').strip()


def ps(script, timeout=30):
    """PowerShell çalıştırır, çıktıyı döndürür."""
    if not WIN:
        raise RuntimeError('Bu işlem yalnız Windows’ta çalışır.')
    r = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
                       capture_output=True, timeout=timeout, creationflags=NO_WINDOW)
    out = r.stdout.decode('utf-8', 'replace') if r.stdout else ''
    err = r.stderr.decode('utf-8', 'replace') if r.stderr else ''
    if r.returncode != 0 and not out.strip():
        raise RuntimeError((err or 'PowerShell hatası').strip()[:600])
    return out.strip()


def inside_home(path):
    p = os.path.realpath(os.path.expanduser(path))
    return p if p.startswith(os.path.realpath(HOME)) else None


def safe_name(n):
    n = ''.join(c for c in str(n) if c.isalnum() or c in ' ._-()çğıöşüÇĞİÖŞÜ').strip()[:80] or 'not'
    return n if os.path.splitext(n)[1].lower() in TEXT_EXT else n + '.txt'


def open_target(t):
    if WIN:
        os.startfile(t)  # noqa
    else:
        webbrowser.open(t)


def mem_info():
    if WIN:
        class MS(ctypes.Structure):
            _fields_ = [('l', ctypes.c_ulong), ('load', ctypes.c_ulong), ('total', ctypes.c_ulonglong), ('avail', ctypes.c_ulonglong),
                        ('tp', ctypes.c_ulonglong), ('ap', ctypes.c_ulonglong), ('tv', ctypes.c_ulonglong), ('av', ctypes.c_ulonglong), ('ae', ctypes.c_ulonglong)]
        m = MS(); m.l = ctypes.sizeof(MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return m.load, m.total / 2**30, (m.total - m.avail) / 2**30
    try:
        info = dict(l.split(':', 1) for l in open('/proc/meminfo'))
        t = int(info['MemTotal'].split()[0]) / 2**20; a = int(info['MemAvailable'].split()[0]) / 2**20
        return round((t - a) / t * 100), t, t - a
    except Exception:
        return 0, 0, 0


def cpu_load():
    if WIN:
        try:
            return int(float(ps('(Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average', 15) or 0))
        except Exception:
            return -1
    try:
        return int(os.getloadavg()[0] * 100 / (os.cpu_count() or 1))
    except Exception:
        return -1


def disk_text():
    root = os.environ.get('SystemDrive', 'C:') + '\\' if WIN else '/'
    d = shutil.disk_usage(root)
    return f'{d.used / 2**30:.0f}/{d.total / 2**30:.0f} GB (%{d.used * 100 // d.total})'


def key_press(vk):
    if not WIN:
        raise RuntimeError('Yalnız Windows')
    ctypes.windll.user32.keybd_event(vk, 0, 0, 0); ctypes.windll.user32.keybd_event(vk, 0, 2, 0)


def screenshot():
    path = os.path.join(WORK, 'Ekran', datetime.datetime.now().strftime('ekran-%Y%m%d-%H%M%S.jpg'))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    ps(f"""Add-Type -AssemblyName System.Windows.Forms,System.Drawing
$b=[System.Windows.Forms.SystemInformation]::VirtualScreen
$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height
$g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($b.Left,$b.Top,0,0,$bmp.Size)
$s=[Math]::Min(1.0,1568/[Math]::Max($b.Width,$b.Height)); $w=[int]($b.Width*$s); $h=[int]($b.Height*$s)
$o=New-Object System.Drawing.Bitmap $bmp,$w,$h
$codec=[System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders()|?{{$_.MimeType -eq 'image/jpeg'}}
$p=New-Object System.Drawing.Imaging.EncoderParameters 1; $p.Param[0]=New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality,[long]80)
$o.Save('{path}',$codec,$p)""", 30)
    with open(path, 'rb') as f:
        return path, base64.b64encode(f.read()).decode()


def tool(name, args, onay):
    """Tek bir izinli işlemi yapar. {'text': ..., 'image'?: base64, 'data'?: {...}} döndürür."""
    a = [str(x) for x in (args or [])]
    a0 = a[0] if a else ''
    if name in RISKY and not onay:
        raise PermissionError('Bu işlem için uygulamada onay gerekiyor.')
    if name == 'durum':
        return {'text': f'{platform.node()} · {platform.system()} {platform.release()} · JARVIS yardımcı {VERSION}'}
    if name in ('ac', 'aç'):
        k = fold(a0)
        cmd = next((v for n, v in APPS.items() if fold(n) == k), None) or next((v for n, v in APPS.items() if k and (k in fold(n) or fold(n) in k)), None)
        if not cmd:
            raise ValueError(f'“{a0}” izin listesinde yok. İzinliler: ' + ', '.join(sorted(set(APPS))))
        if cmd.endswith(':'):
            open_target(cmd)
        elif WIN:
            subprocess.Popen(['cmd', '/c', 'start', '', cmd], creationflags=NO_WINDOW)
        else:
            raise RuntimeError('Yalnız Windows')
        time.sleep(1.5)
        running = proc_running(PROC.get(cmd)) if PROC.get(cmd) else None
        return {'text': f'{a0} açıldı' + (' (çalıştığı doğrulandı)' if running else ' (komut verildi; pencere birkaç saniyede gelir)' if running is None else ' komutu verildi ama süreç görünmüyor; program kurulu olmayabilir')}
    if name == 'kapat':
        k = fold(a0); cmd = next((v for n, v in APPS.items() if fold(n) == k), None)
        exe = PROC.get(cmd or '', None) or (a0 if a0.lower().endswith('.exe') else None)
        if not exe:
            raise ValueError('Bu program için kapatma tanımlı değil')
        subprocess.run(['taskkill', '/IM', exe], capture_output=True, creationflags=NO_WINDOW)
        time.sleep(1.2)
        return {'text': f'{a0} ' + ('kapandı (doğrulandı)' if not proc_running(exe) else 'kapatma isteği gönderildi; kaydedilmemiş belge sorusu açık olabilir')}
    if name == 'sistem' or name == 'sistem_ozet':
        load, total, used = mem_info(); cpu = cpu_load()
        data = {'CPU': f'%{cpu}' if cpu >= 0 else '?', 'RAM': f'{used:.1f}/{total:.1f} GB (%{load})', 'Disk': disk_text()}
        if name == 'sistem_ozet':
            return {'text': 'ok', 'data': data}
        top = ''
        if WIN:
            try:
                top = ps("Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 6 | ForEach-Object { '{0} {1:N0} MB' -f $_.ProcessName, ($_.WorkingSet64/1MB) }", 20)
            except Exception:
                pass
        up = ''
        if WIN:
            ms = ctypes.windll.kernel32.GetTickCount64(); up = f', açık kalma {ms // 3600000} sa'
        return {'text': f"CPU %{cpu}, RAM {data['RAM']}, disk {data['Disk']}{up}. En çok bellek kullananlar: " + top.replace('\r', '').replace('\n', '; ')}
    if name == 'baslangic':
        return {'text': ps("Get-CimInstance Win32_StartupCommand | ForEach-Object { $_.Name + ' — ' + $_.Location }", 20) or 'Başlangıç programı bulunamadı'}
    if name == 'dosya_ara':
        q = fold(a0); root = inside_home(a[1]) if len(a) > 1 and a[1] else HOME
        if not q:
            raise ValueError('Aranacak ad gerekli')
        found, t0 = [], time.time()
        for top in (['Desktop', 'Documents', 'Downloads', 'Pictures', 'Videos', 'Music', 'OneDrive'] if root == HOME else ['']):
            start = os.path.join(root, top)
            for dp, dn, fn in os.walk(start):
                dn[:] = [d for d in dn if not d.startswith('.') and d not in ('node_modules', 'AppData', '$RECYCLE.BIN')]
                for f in fn:
                    if q in fold(f):
                        found.append(os.path.join(dp, f))
                if len(found) >= 25 or time.time() - t0 > 8:
                    break
            if len(found) >= 25 or time.time() - t0 > 8:
                break
        return {'text': '\n'.join(found[:25]) or 'Bulunamadı'}
    if name == 'dosya_oku':
        p = inside_home(a0)
        if not p or not os.path.isfile(p) or not p.lower().endswith(TEXT_EXT):
            raise ValueError('Yalnız kullanıcı klasöründeki metin dosyaları okunabilir')
        with open(p, encoding='utf-8', errors='replace') as f:
            return {'text': f.read(8000)}
    if name == 'dosya_olustur':
        os.makedirs(WORK, exist_ok=True)
        p = os.path.join(WORK, safe_name(a0))
        with open(p, 'w', encoding='utf-8') as f:
            f.write('|'.join(a[1:]) if len(a) > 1 else '')
        ok = os.path.isfile(p)
        return {'text': f'Dosya oluşturuldu: {p} ({os.path.getsize(p)} bayt, doğrulandı)' if ok else 'Dosya oluşturulamadı'}
    if name == 'klasor_ac':
        p = inside_home(a0 or WORK) or WORK
        os.makedirs(p, exist_ok=True) if p == WORK else None
        open_target(p); return {'text': 'Klasör açıldı: ' + p}
    if name == 'ekran':
        p, b64 = screenshot(); return {'text': 'Ekran görüntüsü alındı: ' + p, 'image': b64}
    if name == 'ses':
        k = fold(a0); vk = {'yukari': 0xAF, 'arttir': 0xAF, 'asagi': 0xAE, 'azalt': 0xAE, 'kapat': 0xAD, 'sessiz': 0xAD, 'ac': 0xAD}.get(k)
        if not vk:
            raise ValueError('ses: yukari / asagi / kapat')
        for _ in range(1 if vk == 0xAD else 5):
            key_press(vk)
        return {'text': 'Ses ayarlandı: ' + a0}
    if name == 'medya':
        vk = {'oynat': 0xB3, 'durdur': 0xB3, 'duraklat': 0xB3, 'sonraki': 0xB0, 'onceki': 0xB1}.get(fold(a0))
        if not vk:
            raise ValueError('medya: oynat / sonraki / onceki')
        key_press(vk); return {'text': 'Medya: ' + a0}
    if name == 'kilitle':
        if not WIN:
            raise RuntimeError('Yalnız Windows')
        ctypes.windll.user32.LockWorkStation(); return {'text': 'Bilgisayar kilitlendi'}
    if name == 'url':
        if not a0.startswith(('http://', 'https://')):
            raise ValueError('Adres http(s) ile başlamalı')
        webbrowser.open(a0); return {'text': 'Tarayıcıda açıldı: ' + a0}
    if name == 'pano':
        text = '|'.join(a)
        ps("Set-Clipboard -Value '" + text.replace("'", "''") + "'", 10)
        return {'text': 'Metin bilgisayarın panosuna kopyalandı (Ctrl+V ile yapıştır)'}
    if name == 'pano_al':
        return {'text': ps('Get-Clipboard -Raw', 10)[:6000] or '(pano boş)'}
    if name == 'gunluk':
        return {'text': ps("Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2} -MaxEvents 12 -ErrorAction SilentlyContinue | ForEach-Object { $_.TimeCreated.ToString('dd.MM HH:mm') + ' ' + $_.ProviderName + ': ' + ($_.Message -split \"`n\")[0] }", 30) or 'Son kritik/hata kaydı yok'}
    if name == 'guncelleme':
        open_target('ms-settings:windowsupdate')
        hf = ''
        try:
            hf = ps("Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 3 | ForEach-Object { $_.HotFixID + ' ' + $_.InstalledOn }", 20)
        except Exception:
            pass
        return {'text': 'Windows Update ekranı açıldı. Son yüklenenler: ' + (hf.replace('\r', '').replace('\n', '; ') or 'bilinmiyor')}
    if name == 'tarama':
        ps('Start-MpScan -ScanType QuickScan', 900)
        res = ps("Get-MpThreatDetection | Select-Object -First 5 | ForEach-Object { $_.ThreatID }", 20)
        return {'text': 'Defender hızlı tarama bitti. ' + ('Tespit: ' + res if res else 'Tehdit bulunmadı.')}
    if name in ('temizlik', 'temizlik_sil'):
        tmp = tempfile.gettempdir(); size = 0; files = []
        for dp, dn, fn in os.walk(tmp):
            for f in fn:
                fp = os.path.join(dp, f)
                try:
                    size += os.path.getsize(fp); files.append(fp)
                except OSError:
                    pass
        if name == 'temizlik':
            return {'text': f'Geçici dosyalar: {len(files)} dosya, {size / 2**20:.0f} MB ({tmp}). Silmek için onaylı “temizlik_sil”.'}
        freed = 0
        for fp in files:
            try:
                s = os.path.getsize(fp); os.remove(fp); freed += s
            except OSError:
                pass
        return {'text': f'{freed / 2**20:.0f} MB geçici dosya silindi (kullanımdaki dosyalar atlandı).'}
    if name == 'yedekle':
        src = inside_home(a0)
        if not src or not os.path.isdir(src):
            raise ValueError('Yedeklenecek klasör kullanıcı klasöründe olmalı')
        dst = os.path.join(WORK, 'Yedekler', os.path.basename(src) + datetime.datetime.now().strftime('-%Y%m%d-%H%M'))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        out = shutil.make_archive(dst, 'zip', src)
        with zipfile.ZipFile(out) as z:
            n = len(z.namelist())
        return {'text': f'Yedek alındı ve doğrulandı: {out} ({n} dosya, {os.path.getsize(out) / 2**20:.1f} MB)'}
    if name == 'yazici':
        return {'text': ps('Get-Printer | ForEach-Object { $_.Name + " (" + $_.PrinterStatus + ")" }', 20) or 'Yazıcı yok'}
    if name == 'monitor':
        return {'text': ps('Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::AllScreens | ForEach-Object { $_.DeviceName + " " + $_.Bounds.Width + "x" + $_.Bounds.Height + $(if($_.Primary){" (ana)"}) }', 15)}
    if name == 'powershell':
        cmd = '|'.join(a)
        if any(x in cmd.lower() for x in ('format-volume', 'remove-item c:\\windows', 'bcdedit', 'diskpart', 'cipher /w')):
            raise PermissionError('Bu komut güvenlik nedeniyle engellendi')
        return {'text': (ps(cmd, 60) or '(çıktı yok)')[:5000]}
    if name == 'yaz':
        text = '|'.join(a)
        esc = ''.join('{' + c + '}' if c in '+^%~(){}[]' else c for c in text)
        ps("$w=New-Object -ComObject WScript.Shell; Start-Sleep -Milliseconds 600; $w.SendKeys('" + esc.replace("'", "''") + "')", 20)
        return {'text': 'Metin etkin pencereye yazıldı'}
    raise ValueError('Bilinmeyen işlem: ' + name)


def proc_running(exe):
    if not WIN or not exe:
        return None
    r = subprocess.run(['tasklist', '/FI', f'IMAGENAME eq {exe}', '/NH'], capture_output=True, creationflags=NO_WINDOW)
    return exe.lower() in r.stdout.decode('utf-8', 'replace').lower()


def run_logged(name, args, onay):
    stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        out = tool(name, args, onay); ok = True
    except Exception as e:  # her hata kullanıcıya açıkça bildirilir
        out = {'error': str(e) or e.__class__.__name__}; ok = False
    try:
        os.makedirs(WORK, exist_ok=True)
        with open(os.path.join(WORK, 'islem-kaydi.txt'), 'a', encoding='utf-8') as f:
            f.write(f"{stamp}\t{'OK' if ok else 'HATA'}\t{name}\t{' | '.join(map(str, args or []))[:200]}\t{(out.get('text') or out.get('error') or '')[:200]}\n")
    except Exception:
        pass
    out['ok'] = ok
    return out


class Handler(BaseHTTPRequestHandler):
    def cors(self):
        o = self.headers.get('Origin', '')
        if o in ORIGINS:
            self.send_header('Access-Control-Allow-Origin', o)
            self.send_header('Vary', 'Origin')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Jarvis-Token')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Private-Network', 'true')

    def reply(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code); self.cors()
        self.send_header('Content-Type', 'application/json; charset=utf-8'); self.send_header('Content-Length', str(len(body)))
        self.end_headers(); self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204); self.cors(); self.end_headers()

    def allowed(self):
        if self.client_address[0] not in ('127.0.0.1', '::1'):
            return False
        if self.headers.get('Origin', '') not in ORIGINS:
            return False
        return hmac.compare_digest(self.headers.get('X-Jarvis-Token', '').strip().upper(), cfg['kod'])

    def do_GET(self):
        if self.path.startswith('/durum'):
            if not self.allowed():
                return self.reply(401, {'ok': False, 'error': 'Erişim kodu yanlış. Bağlantı sekmesine yardımcı penceresindeki kodu gir.'})
            return self.reply(200, {'ok': True, 'pc': platform.node(), 'version': VERSION, 'relay': bool(cfg.get('gist'))})
        self.reply(404, {'ok': False})

    def do_POST(self):
        if not self.allowed():
            return self.reply(401, {'ok': False, 'error': 'Erişim kodu yanlış. Bağlantı sekmesine yardımcı penceresindeki kodu gir.'})
        n = int(self.headers.get('Content-Length', '0') or 0)
        try:
            d = json.loads(self.rfile.read(min(n, 2_000_000)) or b'{}')
        except Exception:
            return self.reply(400, {'ok': False, 'error': 'Geçersiz istek'})
        if self.path == '/eslestir':
            cfg.update({'gh': d.get('token', ''), 'gist': d.get('gist', ''), 'anahtar': d.get('anahtar', '')}); save_cfg(cfg)
            print('Telefon köprüsü eşleştirildi.')
            return self.reply(200, {'ok': True})
        if self.path == '/run':
            out = run_logged(fold(d.get('tool')).replace(' ', '_'), d.get('args') or [], bool(d.get('onay')))
            return self.reply(200 if out['ok'] else 422, out)
        self.reply(404, {'ok': False})

    def log_message(self, *a):
        pass


def relay_loop():
    """Telefon köprüsü: Gist'teki imzalı komutları okur, sonuçları yazar."""
    seen = set()
    while True:
        time.sleep(4)
        if not (cfg.get('gh') and cfg.get('gist') and cfg.get('anahtar')):
            continue
        try:
            req = urllib.request.Request('https://api.github.com/gists/' + cfg['gist'], headers={'Authorization': 'Bearer ' + cfg['gh'], 'Accept': 'application/vnd.github+json', 'Cache-Control': 'no-cache'})
            files = json.load(urllib.request.urlopen(req, timeout=15))['files']
            cmds = json.loads((files.get('pc-komut.json') or {}).get('content') or '{}').get('komutlar', [])
            try:
                results = json.loads((files.get('pc-sonuc.json') or {}).get('content') or '{}')
            except Exception:
                results = {}
            changed = False
            for c in cmds:
                cid = c.get('id')
                if not cid or cid in seen or cid in results:
                    continue
                seen.add(cid)
                msg = f"{cid}{c.get('tool')}{json.dumps(c.get('args'), ensure_ascii=False, separators=(',', ':'))}{c.get('ts')}"
                good = hmac.compare_digest(hmac.new(bytes.fromhex(cfg['anahtar']), msg.encode('utf-8'), hashlib.sha256).hexdigest(), str(c.get('sig')))
                fresh = abs(time.time() * 1000 - float(c.get('ts') or 0)) < 300_000
                if not good or not fresh:
                    results[cid] = {'ok': False, 'error': 'İmza veya zaman geçersiz; komut reddedildi'}
                else:
                    print('Telefondan komut:', c.get('tool'), c.get('args'))
                    out = run_logged(fold(c.get('tool')).replace(' ', '_'), c.get('args') or [], bool(c.get('onay')))
                    out.pop('image', None) if len(out.get('image', '')) > 600_000 else None
                    results[cid] = out
                changed = True
            if changed:
                results = dict(list(results.items())[-20:])
                body = json.dumps({'files': {'pc-sonuc.json': {'content': json.dumps(results, ensure_ascii=False)}}}).encode('utf-8')
                urllib.request.urlopen(urllib.request.Request('https://api.github.com/gists/' + cfg['gist'], data=body, method='PATCH', headers={'Authorization': 'Bearer ' + cfg['gh'], 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'}), timeout=20)
        except Exception as e:
            if '401' in str(e):
                print('GitHub anahtarı geçersiz; telefon köprüsü durdu.')
                time.sleep(60)


def main():
    os.makedirs(WORK, exist_ok=True)
    print('=' * 56)
    print(f'  JARVIS bilgisayar yardımcısı {VERSION}')
    print(f'  ERİŞİM KODU:  {cfg["kod"]}')
    print('  JARVIS → BAĞLANTI → “Yardımcı erişim kodu” kutusuna yaz.')
    print('  Bu pencere açık kaldıkça JARVIS bilgisayarını kullanabilir.')
    print('=' * 56)
    threading.Thread(target=relay_loop, daemon=True).start()
    srv = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    if '--kod' in sys.argv:
        print(cfg['kod'])
    elif '--test' in sys.argv:
        print(json.dumps(run_logged(sys.argv[2], sys.argv[3:], True), ensure_ascii=False))
    else:
        main()
